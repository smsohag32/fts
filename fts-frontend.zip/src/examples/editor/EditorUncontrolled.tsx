'use client'

// Styled Component Import
import AppReactDraftWysiwyg from '@/libs/styles/AppReactDraftWysiwyg'

const EditorUncontrolled = () => <AppReactDraftWysiwyg />

export default EditorUncontrolled
