export const icons = ['ri-plane-line', 'ri-a-b', 'ri-grid-fill', 'ri-whatsapp-line', 'ri-building-line']
