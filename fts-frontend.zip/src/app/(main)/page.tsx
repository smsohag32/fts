export default function HomePage() {
  return <div className='py-10 '>Home page</div>
}
